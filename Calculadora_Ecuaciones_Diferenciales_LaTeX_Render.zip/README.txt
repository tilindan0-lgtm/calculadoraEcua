# Calculadora de Ecuaciones Diferenciales (LaTeX bonito)

## Render
Build Command: pip install -r requirements.txt
Start Command: gunicorn app:app

## Potencias
Puedes escribir potencias como x^2 (recomendado) o x**2 (también aceptado).
